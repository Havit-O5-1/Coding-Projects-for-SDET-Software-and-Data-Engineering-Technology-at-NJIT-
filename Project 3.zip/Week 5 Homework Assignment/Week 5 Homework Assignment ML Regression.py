# Import necessary libraries
import pandas as pd  # For data manipulation and analysis
import numpy as np   # For numerical operations
import matplotlib.pyplot as plt  # For data visualization
import seaborn as sns  # For advanced data visualization
from sklearn.model_selection import train_test_split, GridSearchCV  # For splitting data and hyperparameter tuning
from sklearn.preprocessing import StandardScaler  # For feature scaling
from sklearn.linear_model import LinearRegression  # For linear regression
from sklearn.tree import DecisionTreeRegressor  # For decision tree regression
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor  # For ensemble models
from sklearn.svm import SVR  # For support vector regression
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score  # For model evaluation

# Part 1: Data Exploration and Preprocessing

# 1. Load the Dataset
# Read the dataset into a Pandas DataFrame
df = pd.read_csv('housing.csv')  # Replace 'housing.csv' with the actual file path
print("Dataset Head:")  # Display the first few rows of the dataset
print(df.head())
print("\nDataset Description:")  # Display basic statistics of the dataset
print(df.describe())

# 2. Handle Missing Data
# Check for missing values in the dataset
print("\nMissing Values:")
print(df.isnull().sum())

# Fill missing values in the 'total_bedrooms' column with the median value
df['total_bedrooms'].fillna(df['total_bedrooms'].median(), inplace=True)

# Verify that missing values have been handled
print("\nMissing Values After Handling:")
print(df.isnull().sum())

# 3. Feature Engineering
# Convert the categorical variable 'ocean_proximity' into numerical values using one-hot encoding
df = pd.get_dummies(df, columns=['ocean_proximity'], drop_first=True)
print("\nDataset After Encoding Categorical Variables:")
print(df.head())

# 4. Feature Scaling
# Normalize numerical features to ensure they are on the same scale
scaler = StandardScaler()
numerical_features = ['longitude', 'latitude', 'housing_median_age', 'total_rooms', 'total_bedrooms', 'population', 'households', 'median_income']
df[numerical_features] = scaler.fit_transform(df[numerical_features])
print("\nDataset After Scaling Numerical Features:")
print(df.head())

# 5. Visualizations
# Plot a histogram of the target variable 'median_house_value'
plt.figure(figsize=(8, 6))
sns.histplot(df['median_house_value'], kde=True)
plt.title('Distribution of Median House Value')
plt.show()

# Create a scatter plot of 'median_house_value' vs 'median_income' for the first 10 rows
plt.figure(figsize=(8, 6))
sns.scatterplot(x=df['median_income'][:10], y=df['median_house_value'][:10])
plt.title('Median House Value vs Median Income (First 10 Rows)')
plt.show()

# Part 2: Model Selection and Training

# 1. Train-Test Split
# Split the dataset into training (80%) and testing (20%) sets
X = df.drop('median_house_value', axis=1)  # Features (all columns except the target)
y = df['median_house_value']  # Target variable
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
print("\nTraining and Testing Sets Created.")

# 2. Implement Regression Models
# Define a dictionary of regression models to train and compare
models = {
    'Linear Regression': LinearRegression(),
    'Decision Tree': DecisionTreeRegressor(random_state=42),
    'Random Forest': RandomForestRegressor(random_state=42),
    'Gradient Boosting': GradientBoostingRegressor(random_state=42),
    'SVR': SVR()
}

# Train each model on the training data
for name, model in models.items():
    model.fit(X_train, y_train)
    print(f"{name} trained.")

# 3. Hyperparameter Tuning (Example for Random Forest)
# Define a grid of hyperparameters to search for the best combination
param_grid = {
    'n_estimators': [100, 200],  # Number of trees in the forest
    'max_depth': [None, 10, 20]  # Maximum depth of each tree
}

# Use GridSearchCV to find the best hyperparameters
grid_search = GridSearchCV(RandomForestRegressor(random_state=42), param_grid, cv=5)
grid_search.fit(X_train, y_train)
print("\nBest Parameters for Random Forest:", grid_search.best_params_)

# Update the best model with the optimal hyperparameters
best_model = grid_search.best_estimator_

# 4. Feature Importance (Example for Random Forest)
# Extract feature importances from the best model
importances = best_model.feature_importances_
feature_importance_df = pd.DataFrame({'Feature': X.columns, 'Importance': importances})
print("\nFeature Importances:")
print(feature_importance_df.sort_values(by='Importance', ascending=False))

# Part 3: Model Evaluation

# 1. Compare Model Performance
# Evaluate each model using MAE, MSE, and R² score
results = {}
for name, model in models.items():
    y_pred = model.predict(X_test)  # Make predictions on the test set
    mae = mean_absolute_error(y_test, y_pred)  # Calculate Mean Absolute Error
    mse = mean_squared_error(y_test, y_pred)  # Calculate Mean Squared Error
    r2 = r2_score(y_test, y_pred)  # Calculate R² score
    results[name] = {'MAE': mae, 'MSE': mse, 'R²': r2}
    print(f"{name} - MAE: {mae}, MSE: {mse}, R²: {r2}")

# 2. Visualize Predictions (Best Model)
# Plot actual vs predicted house values for the best-performing model
y_pred_best = best_model.predict(X_test)
plt.figure(figsize=(8, 6))
plt.scatter(y_test, y_pred_best)
plt.xlabel('Actual Values')
plt.ylabel('Predicted Values')
plt.title('Actual vs Predicted House Values (Best Model)')
plt.show()

# 3. Interpretability
print("\nInterpretability:")
print("Random Forest performed the best due to its ability to capture non-linear relationships and interactions between features.")
print("Feature scaling improved the performance of models like SVR and Linear Regression, which are sensitive to feature magnitudes.")

# Part 4: Conclusion and Reflection

# 1. Summary of Findings
print("\nSummary of Findings:")
print("- Random Forest and Gradient Boosting performed the best in terms of R² score.")
print("- Feature scaling and encoding categorical variables were crucial for model performance.")
print("- Median income was the most important feature for predicting house values.")

# 2. Challenges Faced
print("\nChallenges Faced:")
print("- Handling missing values in the 'total_bedrooms' column.")
print("- Tuning hyperparameters for models like SVR and Random Forest.")

# 3. Future Improvements
print("\nFuture Improvements:")
print("- Experiment with deep learning models like neural networks.")
print("- Add more features such as crime rate or school quality.")
print("- Use ensemble techniques like stacking or blending.")

# End of Code