# Step 1: Load the Dataset
# Import necessary libraries
import pandas as pd
import numpy as np
from sklearn.feature_selection import VarianceThreshold, mutual_info_regression
from sklearn.preprocessing import MinMaxScaler, LabelEncoder, OneHotEncoder

# Load the dataset
df = pd.read_csv('week4.csv')

# Display the first few rows to understand the data
print("Step 1: Load the Dataset")
print(df.head())

# Step 2: Handle Duplicates
# Check for duplicate rows
duplicate_rows = df.duplicated().sum()
print(f"\nStep 2: Handle Duplicates\nNumber of duplicate rows: {duplicate_rows}")

# Remove duplicate rows
df = df.drop_duplicates()
print(f"Duplicate rows removed. Remaining rows: {len(df)}")

# Step 3: Remove Unnecessary Columns
# Drop the "capital" column because it's not needed
df = df.drop(columns=['capital'])
print("\nStep 3: Remove Unnecessary Columns\n'capital' column dropped.")

# Step 4: Handle Missing Values
# Check which columns have missing values
missing_values = df.isnull().sum()
print("\nStep 4: Handle Missing Values")
print("Missing values per column:")
print(missing_values)

# Step 5: Convert Income Column to Numeric Format
# Remove dollar signs and commas from the "income" column
df['income'] = df['income'].str.replace('$', '').str.replace(',', '')

# Convert the cleaned column to numeric
df['income'] = pd.to_numeric(df['income'], errors='coerce')
print("\nStep 5: Convert Income Column to Numeric Format\n'income' column cleaned and converted to numeric.")

# Step 6: Convert Specific Columns to Numeric Format
# List of numeric columns to clean
numeric_columns = ['life_expectancy', 'income', 'population', 'literacy_rate', 'visitors_per_year']

# Convert these columns to numeric, handling errors
for col in numeric_columns:
    df[col] = pd.to_numeric(df[col], errors='coerce')

# Fill missing values in numeric columns with the median
df[numeric_columns] = df[numeric_columns].fillna(df[numeric_columns].median())
print("\nStep 6: Convert Specific Columns to Numeric Format\nNumeric columns cleaned and missing values filled with median.")

# Step 7: Handle Outliers Using IQR Method
# Calculate IQR for numeric columns
Q1 = df[numeric_columns].quantile(0.25)
Q3 = df[numeric_columns].quantile(0.75)
IQR = Q3 - Q1

# Define lower and upper bounds for outliers
lower_bound = Q1 - 1.5 * IQR
upper_bound = Q3 + 1.5 * IQR

# Remove rows containing outliers
df = df[~((df[numeric_columns] < lower_bound) | (df[numeric_columns] > upper_bound)).any(axis=1)]
print(f"\nStep 7: Handle Outliers Using IQR Method\nRows remaining after removing outliers: {len(df)}")

# Additional Experimentation: Outlier Detection with Random Data
# Generate random data with some outliers
np.random.seed(42)
data = {
    'A': np.append(np.random.randint(10, 50, 18), [200, 250]),
    'B': np.append(np.random.randint(100, 200, 18), [5, 500]),
    'C': np.append(np.random.randint(5, 25, 18), [100, 150]),
}

df_random = pd.DataFrame(data)
print("\nAdditional Experimentation: Outlier Detection with Random Data")
print("Original Random Data:")
print(df_random)

# Calculate IQR for the random data
Q1_random = df_random.quantile(0.25)
Q3_random = df_random.quantile(0.75)
IQR_random = Q3_random - Q1_random

# Define lower and upper bounds for outliers
lower_bound_random = Q1_random - 1.5 * IQR_random
upper_bound_random = Q3_random + 1.5 * IQR_random

# Remove rows containing outliers
df_random_filtered = df_random[~((df_random < lower_bound_random) | (df_random > upper_bound_random)).any(axis=1)]
print("\nFiltered Random Data (Outliers Removed):")
print(df_random_filtered)

# Step 8: Feature Selection Using Variance Threshold
# Apply Variance Threshold to remove features with low variance
selector = VarianceThreshold(threshold=0.01)  # Adjust threshold as needed
selector.fit(df[numeric_columns])

# Get the names of the selected features
selected_features = df[numeric_columns].columns[selector.get_support()]
print("\nStep 8: Feature Selection Using Variance Threshold")
print(f"Selected features: {selected_features.tolist()}")

# Step 9: Feature Selection Using Mutual Information
# Compute mutual information scores for feature selection
X = df[['life_expectancy', 'population', 'literacy_rate', 'visitors_per_year']]
y = df['income']

mi_scores = mutual_info_regression(X, y)
mi_threshold = 0.1  # Adjust threshold as needed
selected_features_mi = X.columns[mi_scores > mi_threshold]
print("\nStep 9: Feature Selection Using Mutual Information")
print(f"Selected features based on mutual information: {selected_features_mi.tolist()}")

# Step 10: Normalize Numeric Features Using Min-Max Scaling
# Apply Min-Max Scaling to numeric columns
scaler = MinMaxScaler()
df[numeric_columns] = scaler.fit_transform(df[numeric_columns])
print("\nStep 10: Normalize Numeric Features Using Min-Max Scaling\nNumeric features scaled.")

# Additional Experimentation: Normalization Techniques
# Generate random data for normalization testing
np.random.seed(42)
data_norm = {
    'A': np.random.randint(10, 100, 10),
    'B': np.random.randint(200, 500, 10),
    'C': np.random.randint(1000, 2000, 10),
}
df_norm = pd.DataFrame(data_norm)
print("\nAdditional Experimentation: Normalization Techniques")
print("Original Random Data for Normalization:")
print(df_norm)

# Z-score normalization
df_zscore = df_norm.copy()
df_zscore = (df_norm - df_norm.mean()) / df_norm.std()
print("\nZ-score Normalized Data:")
print(df_zscore)

# Min-Max normalization
df_minmax = df_norm.copy()
df_minmax = (df_norm - df_norm.min()) / (df_norm.max() - df_norm.min())
print("\nMin-Max Normalized Data:")
print(df_minmax)

# Step 11: Encode Categorical Variables
# Apply Label Encoding to "english_spoken" (Yes -> 1, No -> 0)
label_encoder = LabelEncoder()
df['english_spoken'] = label_encoder.fit_transform(df['english_spoken'])

# Apply One-Hot Encoding to "continent" (drop one category to avoid multicollinearity)
onehot_encoder = OneHotEncoder(drop='first', sparse_output=False)
continent_encoded = onehot_encoder.fit_transform(df[['continent']])
continent_encoded_df = pd.DataFrame(continent_encoded, columns=onehot_encoder.get_feature_names_out(['continent']))

# Add the encoded columns to the dataframe and drop the original "continent" column
df = pd.concat([df, continent_encoded_df], axis=1)
df = df.drop(columns=['continent'])
print("\nStep 11: Encode Categorical Variables\nCategorical variables encoded.")

# Step 12: Set Index
# Set "country" as the index for easier referencing
df = df.set_index('country')
print("\nStep 12: Set Index\n'country' column set as index.")

# Display the final processed dataset
print("\nFinal Processed Dataset:")
print(df.head())